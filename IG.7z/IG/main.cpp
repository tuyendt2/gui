#include "mainwindow.h"
#include <iostream>
#include <QApplication>
#include <QWidget>
#include <delegate.h>
#include <QTableWidget>
#include<QTableWidgetItem>
#include <QSpacerItem>
#include <QMainWindow>
#include <QDialog>
#include <QAbstractTableModel>
#include<QTableView>
#include <QGroupBox>
#include<QGridLayout>
#include<QTabWidget>
#include <QComboBox>
#include <QActionGroup>
#include <QMenu>
#include<QPushButton>
#include<delegate.h>
#include<combobox.h>
#include<checkbox.h>
#include<table.h>
using namespace std;
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}
