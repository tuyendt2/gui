#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QWidget>
#include <delegate.h>
#include <QTableWidget>
#include<QTableWidgetItem>
#include <QSpacerItem>
#include<iostream>
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QWidget *main_widget = new QWidget(this);
    QVBoxLayout *main_layout = new QVBoxLayout;

    tabWidget = new QTabWidget;
    cout<<"hehe"<<endl;
    tabWidget->addTab(new Standard,tr("Standard"));
    tabWidget->addTab(new CAN,tr("CAN"));
    tabWidget->setTabPosition(QTabWidget::South);

    button = new QHBoxLayout;
    New = new QMenu(tr("New"));
    Can_Message = new QAction(tr("CAN message"));
    linMessage= new QAction(tr("LIN message"));
    New->addAction(Can_Message);
    defaultMode= new QMenu(tr("defalut mode"));
    defaultGroup = new QActionGroup(this);
    canMode= new QAction(tr("CAN"));
    canMode->setCheckable(true);
    linMode= new QAction(tr("LIN"));
    linMode->setCheckable(true);
    defaultGroup->addAction(canMode);
    defaultGroup->addAction(linMode);
    defaultGroup->setEnabled(true);
    canMode->setChecked(true);

    defaultMode->addAction(canMode);
    defaultMode->addAction(linMode);
    New->addMenu(defaultMode);
    newButton = new QPushButton("New");
    newButton->setMenu(New);

    cloneButton = new QPushButton("Clone");

    specialFrame = new QMenu("Special Frame");
    canErrorFrame= new QAction("Error Frame");
    specialFrame->addAction(canErrorFrame);
    specialFrameButton = new QPushButton("Special Frame");
    specialFrameButton->setMenu(specialFrame);

    delButton = new QPushButton("Delete");
    cutButton= new QPushButton("Cut");
    copyButton= new QPushButton("Copy");
    pasteButton = new QPushButton("Paste");
    layOutButton= new QPushButton("Layout");

    button->addWidget(newButton);
    button->addWidget(cloneButton);
    button->addWidget(specialFrameButton);
    button->addWidget(delButton);
    button->addWidget(cutButton);
    button->addWidget(pasteButton);
    button->addWidget(copyButton);
    button->addWidget(layOutButton);

//    signalTable =new QTableView();
//    MyModel *signalTableModel = new MyModel(0);
//    signalTableModel->listHeader=(new QString("SB;Signal;Raw value;Phys value;Unit;Dec;Phys Step;Inc;Wave form Generation"))->split(";");
//    signalTable->setModel(signalTableModel);
//    SpinBoxDelegate delegate;
//    signalTable->setItemDelegate(&delegate);
   // signalTable->show();


    main_layout->addWidget(tabWidget);
    main_layout->addLayout(button);
    QVBoxLayout *signalBlock= new QVBoxLayout;
    QHBoxLayout *bottom =new QHBoxLayout;
    QVBoxLayout *actionButton = new QVBoxLayout;
    QPushButton *help=new QPushButton(QString("Help"));
    QPushButton *close= new QPushButton(QString("Close"));
    QSpacerItem *spacer = new QSpacerItem(300,30,QSizePolicy::MinimumExpanding,QSizePolicy::MinimumExpanding);
    help->setFixedSize(80,30);
    close->setFixedSize(80,30);
    actionButton->addWidget(help);
    actionButton->addWidget(close);
    bottom->addItem(spacer);
    bottom->addLayout(actionButton);

    QWidget *sig = new SIG;
    signalBlock->addWidget(sig);
    signalBlock->addLayout(bottom);
    main_layout->addLayout(signalBlock);
    main_widget->setLayout(main_layout);
    setCentralWidget(main_widget);
    setWindowTitle("IG");
}

MainWindow::~MainWindow()
{
    delete ui;
}

QWidget *MainWindow::standardTable()
{
    QTableWidget* table = new QTableWidget();

    //Set table row count 1 and column count 3
    table->setRowCount(7);
    table->setColumnCount(15);
    table->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

    //Set Header Label Texts Here
    //table->setHorizontalHeaderLabels(QString("Message Name;Msg Params;Triggering;Data Field").split(";"));
    table->horizontalHeader()->setVisible(false);
    table->verticalHeader()->setVisible(false);

    QTableWidgetItem* MessageName = new QTableWidgetItem("Message");
    QTableWidgetItem *MsgParams = new QTableWidgetItem("Msg Params");
    QTableWidgetItem* Triggering = new QTableWidgetItem("Triggering");
    QTableWidgetItem *DataField = new QTableWidgetItem("Data Field");
    QTableWidgetItem *CycleTime = new QTableWidgetItem("Cycle Time [ms]");
    MessageName->setTextAlignment(Qt::AlignCenter);
    MsgParams->setTextAlignment(Qt::AlignCenter);
    Triggering->setTextAlignment(Qt::AlignCenter);
    DataField->setTextAlignment(Qt::AlignCenter);
    CycleTime->setTextAlignment(Qt::AlignCenter);
    //Add Table items here
    table->setItem(0,0,MessageName);
    table->setSpan(0,0,2,1);
    table->setItem(0,1,MsgParams);
    table->setSpan(0,1,1,2);
    table->setItem(0,3,Triggering);
    table->setSpan(0,3,1,4);
    table->setItem(0,7,DataField);
    table->setSpan(0,7,1,8);
    table->setItem(1,1,new QTableWidgetItem ("Channel",QFont::Black));
    table->setItem(1,2,new QTableWidgetItem ("DLC"));
    table->setItem(1,3,new QTableWidgetItem ("Send"));
    table->setItem(1,4,CycleTime);
    table->setSpan(1,4,1,3);
    table->setItem(1,7,new QTableWidgetItem ("0"));
    table->setItem(1,8,new QTableWidgetItem ("1"));
    table->setItem(1,9,new QTableWidgetItem ("2"));
    table->setItem(1,10,new QTableWidgetItem ("3"));
    table->setItem(1,11,new QTableWidgetItem ("4"));
    table->setItem(1,12,new QTableWidgetItem ("5"));
    table->setItem(1,13,new QTableWidgetItem ("6"));
    table->setItem(1,14,new QTableWidgetItem ("7"));

    //table->horizontalHeader()->setStretchLastSection(true);
    for(int i=0;i<15;i++){
  if(i>6){
      table->setColumnWidth(i,40);
    }
  else{
      table->setColumnWidth(i,80);
  }
  if(i==0)table->setColumnWidth(i,100);

    }

//    ComboBoxDeleGate delegate;
//    table->horizontalHeader()->setStretchLastSection(true);
//    table->setItemDelegateForColumn(1,&delegate);
//    ComboBox combobox;
//    table->horizontalHeader()->setStretchLastSection(true);
//    table->setItemDelegateForColumn(2,&combobox);
//    table->setItem(2,3,new QTableWidgetItem ("now"));
//    CheckBoxDeleGate checkbox;
//    table->setItemDelegateForColumn(4,&checkbox);
//    LabelDeleGate label;
//    table->setItemDelegateForColumn(5,&label);
//    SliderDeleGate slider;
//    table->setItemDelegateForColumn(6,&slider);
    return table;
}

Standard::Standard(QWidget *parent)
{
    QTableWidget* table = new QTableWidget();

    //Set table row count 1 and column count 3
    table->setRowCount(7);
    table->setColumnCount(15);
    table->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

    //Set Header Label Texts Here
    //table->setHorizontalHeaderLabels(QString("Message Name;Msg Params;Triggering;Data Field").split(";"));
    table->horizontalHeader()->setVisible(false);
    table->verticalHeader()->setVisible(false);

    QTableWidgetItem* MessageName = new QTableWidgetItem("Message");
    QTableWidgetItem *MsgParams = new QTableWidgetItem("Msg Params");
    QTableWidgetItem* Triggering = new QTableWidgetItem("Triggering");
    QTableWidgetItem *DataField = new QTableWidgetItem("Data Field");
    QTableWidgetItem *CycleTime = new QTableWidgetItem("Cycle Time [ms]");
    MessageName->setTextAlignment(Qt::AlignCenter);
    MsgParams->setTextAlignment(Qt::AlignCenter);
    Triggering->setTextAlignment(Qt::AlignCenter);
    DataField->setTextAlignment(Qt::AlignCenter);
    CycleTime->setTextAlignment(Qt::AlignCenter);
    //Add Table items here
    table->setItem(0,0,MessageName);
    table->setSpan(0,0,2,1);
    table->setItem(0,1,MsgParams);
    table->setSpan(0,1,1,2);
    table->setItem(0,3,Triggering);
    table->setSpan(0,3,1,4);
    table->setItem(0,7,DataField);
    table->setSpan(0,7,1,8);
    table->setItem(1,1,new QTableWidgetItem ("Channel",QFont::Black));
    table->setItem(1,2,new QTableWidgetItem ("DLC"));
    table->setItem(1,3,new QTableWidgetItem ("Send"));
    table->setItem(1,4,CycleTime);
    table->setSpan(1,4,1,3);
    table->setItem(1,7,new QTableWidgetItem ("0"));
    table->setItem(1,8,new QTableWidgetItem ("1"));
    table->setItem(1,9,new QTableWidgetItem ("2"));
    table->setItem(1,10,new QTableWidgetItem ("3"));
    table->setItem(1,11,new QTableWidgetItem ("4"));
    table->setItem(1,12,new QTableWidgetItem ("5"));
    table->setItem(1,13,new QTableWidgetItem ("6"));
    table->setItem(1,14,new QTableWidgetItem ("7"));

    //table->horizontalHeader()->setStretchLastSection(true);
    for(int i=0;i<15;i++){
  if(i>6){
      table->setColumnWidth(i,40);
    }
  else{
      table->setColumnWidth(i,80);
  }
  if(i==0)table->setColumnWidth(i,100);

    }
// delegate khi them delegate thi bi loi, anh fix dum em
    ComboBoxDeleGate delegate;
    table->horizontalHeader()->setStretchLastSection(true);
    table->setItemDelegateForColumn(1,&delegate);
    ComboBox combobox;
    table->horizontalHeader()->setStretchLastSection(true);
    table->setItemDelegateForColumn(2,&combobox);
    table->setItem(2,3,new QTableWidgetItem ("now"));
    CheckBoxDeleGate checkbox;
    table->setItemDelegateForColumn(4,&checkbox);
    LabelDeleGate label;
    table->setItemDelegateForColumn(5,&label);
    SliderDeleGate slider;
    table->setItemDelegateForColumn(6,&slider);

    QLayout *layout=new QHBoxLayout;
    layout->addWidget(table);
    this->setLayout(layout);
}

CAN::CAN(QWidget *parent)
{
//    QTableView *canMessage= new QTableView();
//    MyModel *model= new MyModel(0);
//    canMessage->setModel(model);
//    model->listHeader=QString("Message Name;Message Parameters;Triggering;Data Field").split(";");
//    QLayout *layout=new QHBoxLayout;
//    layout->addWidget(canMessage);
//    this->setLayout(layout);


    QTableWidget* table = new QTableWidget();

    //Set table row count 1 and column count 3
    table->setRowCount(7);
    table->setColumnCount(24);
    table->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

    table->horizontalHeader()->setVisible(false);
    table->verticalHeader()->setVisible(false);

    QTableWidgetItem* MessageName = new QTableWidgetItem("Message Name");
    QTableWidgetItem *MsgParams = new QTableWidgetItem("Message Parameters");
    QTableWidgetItem* Triggering = new QTableWidgetItem("Triggering");
    QTableWidgetItem *DataField = new QTableWidgetItem("Data Field");
    MessageName->setTextAlignment(Qt::AlignCenter);
    MsgParams->setTextAlignment(Qt::AlignCenter);
    Triggering->setTextAlignment(Qt::AlignCenter);
    DataField->setTextAlignment(Qt::AlignCenter);
    //Add Table items here
    table->setItem(0,0,MessageName);
    table->setSpan(0,0,2,1);
    table->setItem(0,1,MsgParams);
    table->setSpan(0,1,1,4);
    table->setItem(0,5,Triggering);
    table->setSpan(0,5,1,11);
    table->setItem(0,16,DataField);
    table->setSpan(0,16,1,8);
    table->setItem(1,1,new QTableWidgetItem ("Identifier",QFont::Black));
    table->setItem(1,2,new QTableWidgetItem ("Channel",QFont::Black));
    table->setItem(1,3,new QTableWidgetItem ("Frame",QFont::Black));
    table->setItem(1,4,new QTableWidgetItem ("DLC"));
    table->setItem(1,5,new QTableWidgetItem ("Send"));
    QTableWidgetItem *key = new QTableWidgetItem("Key");
    key->setTextAlignment(Qt::AlignCenter);
    table->setItem(1,6,key);
    table->setSpan(1,6,1,3);
    QTableWidgetItem *cycleTime = new QTableWidgetItem ("Cycle time [ms]",QFont::Black);
    cycleTime->setTextAlignment(Qt::AlignCenter);
    table->setItem(1,9,cycleTime);
    table->setSpan(1,9,1,3);
    table->setItem(1,12,new QTableWidgetItem ("Burst",QFont::Black));
    table->setItem(1,13,new QTableWidgetItem ("Highload"));
    QTableWidgetItem *gateWay=new QTableWidgetItem ("Gateway");

    gateWay->setTextAlignment(Qt::AlignCenter);
    table->setItem(1,14,gateWay);
    table->setSpan(1,14,1,2);
    table->setItem(1,16,new QTableWidgetItem ("0"));
    table->setItem(1,17,new QTableWidgetItem ("1"));
    table->setItem(1,18,new QTableWidgetItem ("2"));
    table->setItem(1,19,new QTableWidgetItem ("3"));
    table->setItem(1,20,new QTableWidgetItem ("4"));
    table->setItem(1,21,new QTableWidgetItem ("5"));
    table->setItem(1,22,new QTableWidgetItem ("6"));
    table->setItem(1,23,new QTableWidgetItem ("7"));

    for(int i=0;i<24;i++){
        if(i==0){
            table->setColumnWidth(i,80);
        }
        else if(i<16){
            table->setColumnWidth(i,60);
        }
        else{
        table->setColumnWidth(i,30);}
    }

    QLayout *layout=new QHBoxLayout;
    layout->addWidget(table);
    this->setLayout(layout);
}

SIG::SIG(QWidget *parent)
{
    QTableWidget* table = new QTableWidget();

    //Set table row count 1 and column count 3
    table->setRowCount(7);
    table->setColumnCount(11);
    table->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Expanding);

    //Set Header Label Texts Here
    //table->setHorizontalHeaderLabels(QString("Message Name;Msg Params;Triggering;Data Field").split(";"));
    table->horizontalHeader()->setVisible(false);
    table->verticalHeader()->setVisible(false);

    QTableWidgetItem* sBit = new QTableWidgetItem("SB");
    QTableWidgetItem *signalName = new QTableWidgetItem("Signal Name");
    QTableWidgetItem* rawVal = new QTableWidgetItem("Raw value");
    QTableWidgetItem *physVal = new QTableWidgetItem("Phys value");
    QTableWidgetItem *unit = new QTableWidgetItem("Unit");
    QTableWidgetItem *dec = new QTableWidgetItem("Dec");
    QTableWidgetItem *physStep = new QTableWidgetItem("Phys step");
    QTableWidgetItem *inc = new QTableWidgetItem("Inc");
    QTableWidgetItem *waveForm = new QTableWidgetItem("Wave form generation");
    sBit->setTextAlignment(Qt::AlignCenter);
    signalName->setTextAlignment(Qt::AlignCenter);
    rawVal->setTextAlignment(Qt::AlignCenter);
    physVal->setTextAlignment(Qt::AlignCenter);
    unit->setTextAlignment(Qt::AlignCenter);
    dec->setTextAlignment(Qt::AlignCenter);
    physStep->setTextAlignment(Qt::AlignCenter);
    inc->setTextAlignment(Qt::AlignCenter);
    waveForm->setTextAlignment(Qt::AlignCenter);
    //Add Table items here
    table->setItem(0,0,sBit);
    table->setItem(0,1,signalName);
    table->setItem(0,2,rawVal);
    table->setItem(0,3,physVal);
    table->setItem(0,4,unit);
    table->setItem(0,5,dec);
    table->setItem(0,6,physStep);
    table->setItem(0,7,inc);
    table->setItem(0,8,waveForm);
    table->setSpan(0,8,1,3);


    QLayout *layout=new QHBoxLayout;
    layout->addWidget(table);
    this->setLayout(layout);
}
