#ifndef TABLE_H
#define TABLE_H
#include <QWidget>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QWidget>
#include <delegate.h>
#include <QTableWidget>
#include<QTableWidgetItem>
#include <QSpacerItem>
#include <QDialog>
#include <QAbstractTableModel>
#include<QTableView>
#include <QGroupBox>
#include<QGridLayout>
#include<QTabWidget>
#include <QComboBox>
#include <QActionGroup>
#include <QMenu>
#include<QPushButton>
#include<delegate.h>
#include<combobox.h>
#include<checkbox.h>
#include<iostream>
using namespace std;
QWidget * main_widget();
QWidget * can_Table();
QWidget *standardTable();
QWidget *sigTable();

#endif // TABLE_H
