#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDialog>
#include <QAbstractTableModel>
#include<QTableView>
#include <QGroupBox>
#include<QGridLayout>
#include<QTabWidget>
#include <QComboBox>
#include <QActionGroup>
#include <QMenu>
#include<QPushButton>
#include<delegate.h>
#include<combobox.h>
#include<checkbox.h>
#include<QWidget>
#include<spinbox.h>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    QWidget *standardTable();

private:
    Ui::MainWindow *ui;
    QTableView *standardView;
    QTableView *canView;
    QGroupBox * groupBox;
    QTabWidget *tabWidget;
    QHBoxLayout *button;
        QMenu *New;
        QAction *Can_Message;
        QAction *linMessage;
        QMenu *defaultMode;
        QActionGroup *defaultGroup;
        QAction *canMode ;
        QAction *linMode;
        QMenu *specialFrame;
        QAction *canErrorFrame;
        QPushButton *delButton;
        QPushButton *cutButton;
        QPushButton *copyButton;
        QPushButton *pasteButton;
        QPushButton *layOutButton;
        QPushButton *cloneButton;
        QPushButton *newButton;
        QPushButton *specialFrameButton;
   QTableView *signalTable;

};
class Standard: public QWidget{
    Q_OBJECT
public:
    Standard(QWidget *parent=0);
};
class CAN: public QWidget{
    Q_OBJECT
public:
    CAN(QWidget *parent=0);
};
class SIG: public QWidget{
    Q_OBJECT
public:
    SIG(QWidget *parent=0);
};


#endif // MAINWINDOW_H
